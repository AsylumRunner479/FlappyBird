﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FlappyBird
{
    public class GroundSpawner : MonoBehaviour
    {
        public GameObject GroundPrefab;     // The column prefab we want to spawn
        public int GroundPoolSize = 5;      // How many columns to keep on standby
        public float GroundspawnRate = 2f;        // How quickly each columns spawn
            
        public Vector3 GroundstandbyPos = new Vector3(-15, 0); // Holding position for the unused columns offscreen
        public float GroundspawnXPos = 10f;

        private GameObject[] Ground;       // Collection of pooled columns
        private int currentGround = 0;      // Index of the current column in the collection
        private float spawnTimer = 0f;

        // Use this for initialization
        void Start()
        {
            // Initialise column pool
            Ground = new GameObject[GroundPoolSize];
            // Loop through the collection...
            for (int i = 0; i < GroundPoolSize; i++)
            {
                // ... and create the individual columns
                Ground[i] = Instantiate(GroundPrefab, GroundstandbyPos, Quaternion.identity);
            }
        }

        // Update is called once per frame
        void Update()
        {
            // Count up the timer
            spawnTimer += Time.deltaTime;
            // Is the game not over AND 
            // Has spawnTimer reached the spawnRate?
            if(GameManager.Instance.gameOver == false && 
               spawnTimer >= GroundspawnRate)
            {
                // Reset timer 
                spawnTimer = 0f;
                // Spawn the column (i.e, Reuse a column)
                SpawnGround();
            }
        }

        void SpawnGround()
        {
            
            // Get current column
            GameObject ground = Ground[currentGround];
            // Set position of current column
            ground.transform.position = new Vector2(GroundspawnXPos, 0);
            // Increase value of current column
            currentGround++; // '++' increments value by 1
            // If the new currentColumn reaches the end of the array
            if(currentGround >= GroundPoolSize)
            {
                // ... set it back to zero
                currentGround = 0;
            }
        }
    }
}